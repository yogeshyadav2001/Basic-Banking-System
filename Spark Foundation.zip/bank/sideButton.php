<form class="form-inline my-2 my-lg-0">
        <a href="" class="btn btn-outline-success" data-toggle="tooltip" title="Your current Account Balance">Account Balance : Rs.<?php echo $userData['balance']; ?></a>  
        <a href="logout.php" data-toggle="tooltip" title="Logout" class="btn btn-outline-danger mx-1" ><i class="fa fa-sign-out fa-fw"></i></a>    
</form>